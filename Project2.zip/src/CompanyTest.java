import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertFalse;
import org.junit.Test;

public class CompanyTest {
    @Test
    /*
     * Invalid inputs are checked for in PayrollProcessing class, therefore
     * JUnit tests only test valid data
     */
    public void testAdd() {
        Company com = new Company();
        Date janeDoe = new Date("07/01/2020");
        Profile prof1 = new Profile("Doe,Jane", "ECE", janeDoe);
        Employee emp1 = new Employee(prof1);
        assertTrue(com.add(emp1)); //test case #1, adding an employee

        assertFalse(com.add(emp1)); //test case #2, adding an existing employee

        assertFalse(com.add(emp1)); //test case #3, adding an employee a second time

        Date johnSmith = new Date("06/22/2005");
        Profile prof2 = new Profile("Smith,John", "CS", johnSmith);
        Parttime emp2 = new Parttime(prof2, (float) 42.5);
        Date michaelBlue = new Date("07/01/2020");
        Profile prof3 = new Profile("Blue,Michael", "ECE", michaelBlue);
        Fulltime emp3 = new Fulltime(prof3, 80000);
        Date nicoleSmith = new Date("02/16/2010");
        Profile prof4 = new Profile("Smith,Nicole", "CS", nicoleSmith);
        Management emp4 = new Management(prof4, 80000, 1);
        Date danGreen = new Date("01/07/2007");
        Profile prof5 = new Profile("Green,Dan", "IT", danGreen);
        Employee emp5 = new Employee(prof5);
        com.add(emp2); //test case #4, adding a part time employee
        com.add(emp3); //test case #5, adding a full time employee
        com.add(emp4); //test case #6, adding a management employee
        assertTrue(com.add(emp5)); //test case #7, adding an employee after the array grow()
    }
    @Test
    public void testRemove() {
        Company com = new Company();
        Date janeDoe = new Date("07/01/2020");
        Profile prof1 = new Profile("Doe,Jane", "ECE", janeDoe);
        Employee emp1 = new Employee(prof1);
        assertFalse(com.remove(emp1)); //test case #1, removing an employee from an empty list

        com.add(emp1);
        assertTrue(com.remove(emp1)); //test case #2, removing all employees in the list

        Date johnSmith = new Date("06/22/2005");
        Profile prof2 = new Profile("Smith,John", "CS", johnSmith);
        Employee emp2 = new Employee(prof2);
        Date michaelBlue = new Date("07/01/2020");
        Profile prof3 = new Profile("Blue,Michael", "ECE", michaelBlue);
        Employee emp3 = new Employee(prof3);
        assertFalse(com.remove(emp2)); //test case #3, removing an employee not in the list from a nonempty list
        com.add(emp2);
        com.add(emp3);
        assertTrue(com.remove(emp2)); //test case #4, removing an employee after multiple are in the array

        Date nicoleSmith = new Date("02/16/2010");
        Profile prof4 = new Profile("Smith,Nicole", "CS", nicoleSmith);
        Employee emp4 = new Employee(prof4);
        Date danGreen = new Date("01/07/2007");
        Profile prof5 = new Profile("Green,Dan", "IT", danGreen);
        Employee emp5 = new Employee(prof5);

        com.add(emp1);
        com.add(emp2);
        com.add(emp4);

        assertTrue(com.remove(emp2)); //test case #5, removing an employee in the middle of the list

        com.add(emp2);
        com.add(emp5);
        assertTrue(com.remove(emp5)); //test case #6, removing an employee after the array grow()

        Employee copy4 = new Employee(prof4);
        assertTrue(com.remove(copy4)); //test case #7, removing an employee by profile, rather than by direct reference
        assertTrue(com.remove(emp3));
        assertTrue(com.remove(emp2));


        assertTrue(com.remove(emp1)); //test case #6, removing all the employees in the list

    }
    @Test
    public void testSetHours() {
        Company com = new Company();
        Date janeDoe = new Date("07/01/2020");
        Profile prof1 = new Profile("Doe,Jane", "ECE", janeDoe);
        Fulltime emp1 = new Fulltime(prof1, 80000);
        assertFalse(com.setHours(emp1)); //test case #1, set hours for an employee not in the database
        com.add(emp1);
        Fulltime emp1Wrapper = new Fulltime(prof1, 0);
        assertFalse(com.setHours(emp1Wrapper)); //test case #2, passing a non Parttime parameter
        Parttime emp1PartTimeWrapper = new Parttime(prof1);
        emp1PartTimeWrapper.setHours(50); //here setHours is a Partttime setter, not Company.setHours
        assertFalse(com.setHours(emp1PartTimeWrapper)); //test case #3, attempting to set hours for a full time employee
        com.remove(emp1);

        Parttime emp2 = new Parttime(prof1, (float) 42.5);
        com.add(emp2);
        Parttime emp2Wrapper = new Parttime(prof1);
        emp2Wrapper.setHours(50);
        assertTrue(com.setHours(emp2Wrapper)); //test case #4, set hours for a parttime employee

    }
}
import static org.junit.Assert.assertEquals;
import org.junit.Test;

public class ManagementTest {
    @Test
    /*
     * Invalid inputs are checked for in PayrollProcessing class, therefore
     * JUnit tests only test valid data
     */
    public void testCalculatePayment() {
        Date janeDoe = new Date("07/01/2020");
        Profile prof1 = new Profile("Doe,Jane", "ECE", janeDoe);
        Management emp1 = new Management(prof1, 80000, 1);
        emp1.calculatePayment();
        //test #1, calculate payment for a manager
        assertEquals(emp1.getPayment(), ((80000.0) / 26 + 5000.0 / 26), 0.0001);

        Management emp2 = new Management(prof1, 90000, 2);
        emp2.calculatePayment();
        //test#2, calculate payment for a department head
        assertEquals(emp2.getPayment(), ((90000.0) / 26 + 9500.0 / 26), 0.0001);

        Management emp3 = new Management(prof1, 100000, 3);
        emp3.calculatePayment();
        //test #3, calculate payment for a director
        assertEquals(emp3.getPayment(), ((100000.0) / 26 + 12000.0 / 26), 0.0001);
    }
}